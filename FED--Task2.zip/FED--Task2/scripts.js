var email = document.getElementById('email');
            var confirmEmail = document.getElementById('confirmEmail');

            function emailForm(event) {
                if (email.value !== confirmEmail.value) {
                    confirmEmail.style.borderColor = 'red'; 
                    confirmEmail.setCustomValidity('Email addresses do not match');
                    event.preventDefault();
                    alert('Email addresses do not match. Please try again'); 
                    return false; 
                } else {
                    confirmEmail.style.borderColor = 'green'; 
                    confirmEmail.setCustomValidity(''); // Reset custom validity
                    alert('You are now registered!');
                    return true; 
                }
            }

            function askQ() { 
                var question = document.getElementById("question").value;
                alert("Question submitted. We'll get back to you on that!");
            }

